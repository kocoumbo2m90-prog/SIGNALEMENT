package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.AppDatabase
import com.example.data.ReportRepository
import com.example.ui.ReportViewModel
import com.example.ui.ReportViewModelFactory
import com.example.ui.WhistleblowerApp
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AudioHelper

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: ReportViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize local database, repository, audio helper and viewModel
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = ReportRepository(database.reportDao())
        val audioHelper = AudioHelper(applicationContext)
        
        val viewModelFactory = ReportViewModelFactory(repository, audioHelper)
        viewModel = ViewModelProvider(this, viewModelFactory)[ReportViewModel::class.java]

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                WhistleblowerApp(viewModel = viewModel)
            }
        }
    }
}

