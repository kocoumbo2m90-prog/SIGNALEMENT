package com.example.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Report
import com.example.data.ReportRepository
import com.example.util.AudioHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class ReportViewModel(
    private val repository: ReportRepository,
    private val audioHelper: AudioHelper
) : ViewModel() {

    // All reports from DB (Flow converted to state)
    val reports: StateFlow<List<Report>> = repository.allReports
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // UI state for creating a new report
    private val _newReportTitle = MutableStateFlow("")
    val newReportTitle = _newReportTitle.asStateFlow()

    private val _newReportDescription = MutableStateFlow("")
    val newReportDescription = _newReportDescription.asStateFlow()

    private val _newReportCategory = MutableStateFlow("Sécurité")
    val newReportCategory = _newReportCategory.asStateFlow()

    private val _newReportSeverity = MutableStateFlow("Moyen")
    val newReportSeverity = _newReportSeverity.asStateFlow()

    private val _latitude = MutableStateFlow<Double?>(null)
    val latitude = _latitude.asStateFlow()

    private val _longitude = MutableStateFlow<Double?>(null)
    val longitude = _longitude.asStateFlow()

    private val _locationAddress = MutableStateFlow<String?>(null)
    val locationAddress = _locationAddress.asStateFlow()

    private val _attachedMediaUri = MutableStateFlow<String?>(null)
    val attachedMediaUri = _attachedMediaUri.asStateFlow()

    private val _attachedMediaType = MutableStateFlow<String?>(null) // "image" or "video" or null
    val attachedMediaType = _attachedMediaType.asStateFlow()

    private val _attachedAudioUri = MutableStateFlow<String?>(null)
    val attachedAudioUri = _attachedAudioUri.asStateFlow()

    private val _isAnonymous = MutableStateFlow(true)
    val isAnonymous = _isAnonymous.asStateFlow()

    // Recording State
    private val _isRecording = MutableStateFlow(false)
    val isRecording = _isRecording.asStateFlow()

    private val _recordingDuration = MutableStateFlow(0)
    val recordingDuration = _recordingDuration.asStateFlow()

    // Playback State
    private val _playingAudioUri = MutableStateFlow<String?>(null)
    val playingAudioUri = _playingAudioUri.asStateFlow()

    // Admin Access State
    private val _isAdminAuthenticated = MutableStateFlow(false)
    val isAdminAuthenticated = _isAdminAuthenticated.asStateFlow()

    private val _adminPinInput = MutableStateFlow("")
    val adminPinInput = _adminPinInput.asStateFlow()

    private val _adminPinError = MutableStateFlow(false)
    val adminPinError = _adminPinError.asStateFlow()

    // Export URI sharing flow
    private val _exportUri = MutableStateFlow<Uri?>(null)
    val exportUri = _exportUri.asStateFlow()

    // Submission status and feedback state
    private val _submissionSuccess = MutableStateFlow(false)
    val submissionSuccess = _submissionSuccess.asStateFlow()

    private var recordingTimerJob: Job? = null
    
    // Admin Detail Active Report
    private val _selectedReport = MutableStateFlow<Report?>(null)
    val selectedReport = _selectedReport.asStateFlow()

    init {
        // Log setup
    }

    fun updateTitle(value: String) { _newReportTitle.value = value }
    fun updateDescription(value: String) { _newReportDescription.value = value }
    fun updateCategory(value: String) { _newReportCategory.value = value }
    fun updateSeverity(value: String) { _newReportSeverity.value = value }
    fun updateAnonymous(value: Boolean) { _isAnonymous.value = value }

    fun updateLocation(lat: Double, lng: Double, address: String?) {
        _latitude.value = lat
        _longitude.value = lng
        _locationAddress.value = address ?: "Lat: $lat, Lng: $lng"
    }

    fun clearLocation() {
        _latitude.value = null
        _longitude.value = null
        _locationAddress.value = null
    }

    fun attachMedia(uri: String, type: String) {
        _attachedMediaUri.value = uri
        _attachedMediaType.value = type
    }

    fun clearMedia() {
        _attachedMediaUri.value = null
        _attachedMediaType.value = null
    }

    fun startVoiceRecording() {
        viewModelScope.launch {
            val file = audioHelper.startRecording()
            if (file != null) {
                _isRecording.value = true
                _recordingDuration.value = 0
                _attachedAudioUri.value = file.absolutePath
                
                recordingTimerJob?.cancel()
                recordingTimerJob = viewModelScope.launch {
                    while (_isRecording.value) {
                        delay(1000)
                        _recordingDuration.value += 1
                        // Max out at 2 minutes
                        if (_recordingDuration.value >= 120) {
                            stopVoiceRecording()
                            break
                        }
                    }
                }
            }
        }
    }

    fun stopVoiceRecording() {
        if (!_isRecording.value) return
        _isRecording.value = false
        recordingTimerJob?.cancel()
        audioHelper.stopRecording()
    }

    fun deleteVoiceRecording() {
        stopVoiceRecording()
        _attachedAudioUri.value?.let { path ->
            try {
                val file = File(path)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _attachedAudioUri.value = null
        _recordingDuration.value = 0
    }

    fun playRecordedAudio(uriString: String) {
        if (_playingAudioUri.value == uriString) {
            stopAudioPlayback()
            return
        }
        
        _playingAudioUri.value = uriString
        audioHelper.playAudio(
            fileUriString = uriString,
            onFinished = {
                _playingAudioUri.value = null
            },
            onError = {
                _playingAudioUri.value = null
            }
        )
    }

    fun stopAudioPlayback() {
        audioHelper.stopPlayback()
        _playingAudioUri.value = null
    }

    // Submit Report
    fun submitReport() {
        viewModelScope.launch {
            if (_newReportTitle.value.isBlank() || _newReportDescription.value.isBlank()) {
                return@launch
            }

            val report = Report(
                title = _newReportTitle.value.trim(),
                description = _newReportDescription.value.trim(),
                category = _newReportCategory.value,
                severity = _newReportSeverity.value,
                latitude = _latitude.value,
                longitude = _longitude.value,
                locationAddress = _locationAddress.value,
                mediaUri = _attachedMediaUri.value,
                mediaType = _attachedMediaType.value,
                audioUri = _attachedAudioUri.value,
                audioDurationSec = _recordingDuration.value,
                isAnonymous = _isAnonymous.value
            )

            repository.insert(report)
            _submissionSuccess.value = true

            // Reset reporting state
            resetReportingForm()
        }
    }

    fun resetSubmissionFlag() {
        _submissionSuccess.value = false
    }

    private fun resetReportingForm() {
        _newReportTitle.value = ""
        _newReportDescription.value = ""
        _newReportCategory.value = "Sécurité"
        _newReportSeverity.value = "Moyen"
        _latitude.value = null
        _longitude.value = null
        _locationAddress.value = null
        _attachedMediaUri.value = null
        _attachedMediaType.value = null
        _attachedAudioUri.value = null
        _isAnonymous.value = true
        _recordingDuration.value = 0
        _isRecording.value = false
        stopAudioPlayback()
    }

    // PIN Admin security
    fun enterAdminDigit(digit: String) {
        if (_adminPinInput.value.length < 4) {
            _adminPinInput.value += digit
            _adminPinError.value = false
        }
        
        if (_adminPinInput.value.length == 4) {
            if (_adminPinInput.value == "1234") { // Default secure pin
                _isAdminAuthenticated.value = true
                _adminPinInput.value = ""
            } else {
                _adminPinError.value = true
                _adminPinInput.value = ""
            }
        }
    }

    fun deleteAdminPinDigit() {
        if (_adminPinInput.value.isNotEmpty()) {
            _adminPinInput.value = _adminPinInput.value.dropLast(1)
            _adminPinError.value = false
        }
    }

    fun clearAdminPin() {
        _adminPinInput.value = ""
        _adminPinError.value = false
    }

    fun logoutAdmin() {
        _isAdminAuthenticated.value = false
        _adminPinInput.value = ""
        _adminPinError.value = false
        _selectedReport.value = null
        stopAudioPlayback()
    }

    // Manage Report
    fun selectReport(report: Report?) {
        _selectedReport.value = report
    }

    fun updateReportStatus(report: Report, newStatus: String, adminNotes: String) {
        viewModelScope.launch {
            val updated = report.copy(status = newStatus, adminNotes = adminNotes)
            repository.update(updated)
            if (_selectedReport.value?.id == report.id) {
                _selectedReport.value = updated
            }
        }
    }

    fun deleteReport(report: Report) {
        viewModelScope.launch {
            repository.delete(report)
            if (_selectedReport.value?.id == report.id) {
                _selectedReport.value = null
            }
        }
    }

    // Excel export invoke
    fun triggerExcelExport(context: Context) {
        viewModelScope.launch {
            val list = reports.value
            val uri = repository.exportToExcelCsv(context, list)
            _exportUri.value = uri
        }
    }

    fun clearExportUri() {
        _exportUri.value = null
    }

    override fun onCleared() {
        super.onCleared()
        stopAudioPlayback()
        recordingTimerJob?.cancel()
    }
}

class ReportViewModelFactory(
    private val repository: ReportRepository,
    private val audioHelper: AudioHelper
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ReportViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ReportViewModel(repository, audioHelper) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
