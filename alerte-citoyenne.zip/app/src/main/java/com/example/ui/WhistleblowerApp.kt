package com.example.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.Report
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhistleblowerApp(viewModel: ReportViewModel) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf<ActiveScreen>(ActiveScreen.UserForm) }
    
    // Simple state flow to bypass navigation module bugs
    val exportUri by viewModel.exportUri.collectAsState()
    val submissionSuccess by viewModel.submissionSuccess.collectAsState()
    
    // Launch Sharing sheet when export is finished
    LaunchedEffect(exportUri) {
        exportUri?.let { uri ->
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/comma-separated-values"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Partager le fichier Excel"))
            viewModel.clearExportUri()
        }
    }
    
    // Toast on report submission success
    LaunchedEffect(submissionSuccess) {
        if (submissionSuccess) {
            Toast.makeText(context, "Sûreté garantie. Signalement envoyé de manière anonyme et cryptée.", Toast.LENGTH_LONG).show()
            viewModel.resetSubmissionFlag()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_scaffold"),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Security Status",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Column {
                            Text(
                                "Alerte Citoyenne",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Plateforme sécurisée et cryptée",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    when (currentScreen) {
                        ActiveScreen.UserForm -> {
                            Button(
                                onClick = { currentScreen = ActiveScreen.AdminLock },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .testTag("admin_portal_button")
                            ) {
                                Icon(
                                    Icons.Default.AdminPanelSettings,
                                    contentDescription = "Admin Area",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Admin", fontSize = 12.sp)
                            }
                        }
                        else -> {
                            IconButton(
                                onClick = {
                                    viewModel.logoutAdmin()
                                    currentScreen = ActiveScreen.UserForm
                                },
                                modifier = Modifier.testTag("exit_admin_button")
                            ) {
                                Icon(
                                    Icons.Default.ExitToApp,
                                    contentDescription = "Exit Admin Mode",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { targetScreen: ActiveScreen ->
                when (targetScreen) {
                    ActiveScreen.UserForm -> {
                        WhistleblowerFormView(viewModel = viewModel)
                    }
                    ActiveScreen.AdminLock -> {
                        AdminLockView(
                            viewModel = viewModel,
                            onSuccess = { currentScreen = ActiveScreen.AdminDashboard },
                            onCancel = { currentScreen = ActiveScreen.UserForm }
                        )
                    }
                    ActiveScreen.AdminDashboard -> {
                        val isAdmin by viewModel.isAdminAuthenticated.collectAsState()
                        if (isAdmin) {
                            AdminDashboardView(viewModel = viewModel)
                        } else {
                            currentScreen = ActiveScreen.AdminLock
                        }
                    }
                }
            }
        }
    }
}

sealed class ActiveScreen {
    object UserForm : ActiveScreen()
    object AdminLock : ActiveScreen()
    object AdminDashboard : ActiveScreen()
}

// ----------------------------------------
// USER FORM VIEW (Lanceur d'alerte)
// ----------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WhistleblowerFormView(viewModel: ReportViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    // Form States from ViewModel
    val title by viewModel.newReportTitle.collectAsState()
    val description by viewModel.newReportDescription.collectAsState()
    val category by viewModel.newReportCategory.collectAsState()
    val severity by viewModel.newReportSeverity.collectAsState()
    val latitude by viewModel.latitude.collectAsState()
    val longitude by viewModel.longitude.collectAsState()
    val locationAddress by viewModel.locationAddress.collectAsState()
    val attachedMediaUri by viewModel.attachedMediaUri.collectAsState()
    val attachedMediaType by viewModel.attachedMediaType.collectAsState()
    val attachedAudioUri by viewModel.attachedAudioUri.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingDuration by viewModel.recordingDuration.collectAsState()
    val playingAudioUri by viewModel.playingAudioUri.collectAsState()
    val isAnonymous by viewModel.isAnonymous.collectAsState()

    // Pick Photo/Video launcher
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val contentResolver = context.contentResolver
            val type = contentResolver.getType(it) ?: ""
            val typeStr = if (type.startsWith("video/")) "video" else "image"
            
            // Take persistent permission if possible to load in admin area
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Ignore if not a content provider persistence URI
            }
            
            viewModel.attachMedia(it.toString(), typeStr)
        }
    }

    // GPS Location Client
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    
    // GPS Permission Launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                      permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                    if (location != null) {
                        viewModel.updateLocation(
                            lat = location.latitude,
                            lng = location.longitude,
                            address = "Localisation GPS Automatique"
                        )
                        Toast.makeText(context, "Localisation trouvée avec succès !", Toast.LENGTH_SHORT).show()
                    } else {
                        // Emulator fallback or GPS turned off
                        Toast.makeText(context, "GPS actif mais aucune coordonnée stockée. Mock activé.", Toast.LENGTH_SHORT).show()
                        viewModel.updateLocation(48.8566, 2.3522, "Paris, Île-de-France (Simulé)")
                    }
                }
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        } else {
            Toast.makeText(context, "Permission refusée. Utilisation de coordonnées fictives.", Toast.LENGTH_SHORT).show()
        }
    }

    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startVoiceRecording()
        } else {
            Toast.makeText(context, "Permission d'enregistrement audio requise.", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Encryption disclaimer
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Encryption lock badge",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            "Donner l'alerte de manière sécurisée",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "Cette application garantit l'anonymat total. Vos fichiers et coordonnées GPS sont cryptés localement. Aucune métadonnée personnelle n'est conservée.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Title and Category Inputs
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "1. Détails du signalement",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                
                OutlinedTextField(
                    value = title,
                    onValueChange = viewModel::updateTitle,
                    label = { Text("Titre de l'alerte") },
                    placeholder = { Text("Ex: Pollution sauvage de rivière, corruption...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_title_input"),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Campaign, contentDescription = null) }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Category drop list
                    var categoryExpanded by remember { mutableStateOf(false) }
                    val categories = listOf("Sécurité", "Environnement", "Corruption", "Santé publique", "Autre")
                    
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Catégorie") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { categoryExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Sélecteur catégorie")
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = categoryExpanded,
                            onDismissRequest = { categoryExpanded = false }
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        viewModel.updateCategory(cat)
                                        categoryExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Severity drop list
                    var severityExpanded by remember { mutableStateOf(false) }
                    val severities = listOf("Faible", "Moyen", "Élevé", "Critique")
                    
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = severity,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Gravité") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { severityExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Sélecteur gravité")
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = severityExpanded,
                            onDismissRequest = { severityExpanded = false }
                        ) {
                            severities.forEach { sev ->
                                DropdownMenuItem(
                                    text = { Text(sev) },
                                    onClick = {
                                        viewModel.updateSeverity(sev)
                                        severityExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = viewModel::updateDescription,
                    label = { Text("Description des faits") },
                    placeholder = { Text("Décrivez en détail la situation observée, les personnes impliquées, les heures...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("report_desc_input"),
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                )
            }
        }

        // Attach Media (Photo or Video)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "2. Joindre une photo ou une vidéo",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (attachedMediaUri == null) {
                    ElevatedCard(
                        onClick = {
                            mediaPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.AddAPhoto,
                                contentDescription = "Add Media",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Sélectionner une photo ou vidéo",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text("Les visages et métadonnées EXIF sont floutés d'office", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            if (attachedMediaType == "image") {
                                AsyncImage(
                                    model = attachedMediaUri,
                                    contentDescription = "Image attachée",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                // Video indicator
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.8f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            Icons.Default.Videocam,
                                            contentDescription = "Vidéo",
                                            tint = Color.White,
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            "Vidéo sélectionnée",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            attachedMediaUri ?: "",
                                            color = Color.LightGray,
                                            fontSize = 10.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(horizontal = 16.dp)
                                        )
                                    }
                                }
                            }

                            // Close Button to delete attachment
                            IconButton(
                                onClick = { viewModel.clearMedia() },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Supprimer le média", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Voice Message Section
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "3. Message vocal (Alternative écrite)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (attachedAudioUri == null) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isRecording) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (isRecording) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(Color.Red)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "ENREGISTREMENT EN COURS : ${String.format("%02d:%02d", recordingDuration / 60, recordingDuration % 60)}",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                IconButton(
                                    onClick = { viewModel.stopVoiceRecording() },
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(Color.Red, CircleShape)
                                        .testTag("audio_stop_record")
                                ) {
                                    Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color.White, modifier = Modifier.size(32.dp))
                                }
                            } else {
                                Text(
                                    "Ajoutez votre témoignage vocal direct déformé pour masquer votre voix.",
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                                IconButton(
                                    onClick = {
                                        val hasPermission = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        
                                        if (hasPermission) {
                                            viewModel.startVoiceRecording()
                                        } else {
                                            recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                                        .testTag("audio_start_record")
                                ) {
                                    Icon(Icons.Default.Mic, contentDescription = "Enregistrer un message vocal", tint = Color.White, modifier = Modifier.size(32.dp))
                                }
                            }
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { viewModel.playRecordedAudio(attachedAudioUri!!) },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                                        .testTag("audio_play_local")
                                ) {
                                    Icon(
                                        imageVector = if (playingAudioUri == attachedAudioUri) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause Speech Testimony",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Témoignage vocal audio", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(
                                        if (playingAudioUri == attachedAudioUri) "Lecture en cours..." else "Prêt à être envoyé",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            
                            IconButton(onClick = { viewModel.deleteVoiceRecording() }) {
                                Icon(Icons.Default.DeleteForever, contentDescription = "Supprimer enregistrement", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }

        // Geolocation Section
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "4. Géolocalisation de l'alerte",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (locationAddress == null) {
                    ElevatedButton(
                        onClick = {
                            val fineLocationGranted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            
                            if (fineLocationGranted) {
                                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                                    if (loc != null) {
                                        viewModel.updateLocation(
                                            loc.latitude,
                                            loc.longitude,
                                            "Localisation GPS Automatique"
                                        )
                                    } else {
                                        viewModel.updateLocation(48.8566, 2.3522, "Paris, Île-de-France (Simulé)")
                                    }
                                }
                            } else {
                                locationPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Obtenir mes coordonnées GPS")
                    }
                    
                    // Quick district tags to easily play and test report filters in admin area
                    Text(
                        "Ou choisissez rapidement une coordonnée simulée :",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val mockLocations = listOf(
                            Triple("Abidjan, Côte-d'Ivoire", 5.3096, -4.0127),
                            Triple("Paris, France", 48.8566, 2.3522),
                            Triple("Montréal, Canada", 45.5017, -73.5673),
                            Triple("Dakar, Sénégal", 14.7167, -17.4677),
                            Triple("Bruxelles, Belgique", 50.8503, 4.3517)
                        )
                        
                        mockLocations.forEach { (label, lat, lng) ->
                            SuggestionChip(
                                onClick = { viewModel.updateLocation(lat, lng, label) },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.MyLocation,
                                    contentDescription = "GPS Localisé",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Position géolocalisée", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(locationAddress ?: "", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("Lat: $latitude, Lng: $longitude", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                            IconButton(onClick = { viewModel.clearLocation() }) {
                                Icon(Icons.Default.Delete, contentDescription = "Enlever coordonnées", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }

        // Anonymous toggle and dispatch button
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Envoyer de manière 100% anonyme", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Votre identité civile et adresse IP ne seront jamais visibles.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    Switch(
                        checked = isAnonymous,
                        onCheckedChange = viewModel::updateAnonymous,
                        modifier = Modifier.testTag("anonymous_switch")
                    )
                }

                Button(
                    onClick = { viewModel.submitReport() },
                    enabled = title.isNotBlank() && description.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("submit_report_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.Send, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("LANCER L'ALERTE SÉCURISÉE", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

// ----------------------------------------
// ADMIN SECURITY LOCK GATE (ADMIN PIN CODE)
// ----------------------------------------
@Composable
fun AdminLockView(
    viewModel: ReportViewModel,
    onSuccess: () -> Unit,
    onCancel: () -> Unit
) {
    val pinInput by viewModel.adminPinInput.collectAsState()
    val isError by viewModel.adminPinError.collectAsState()
    val isAuthenticated by viewModel.isAdminAuthenticated.collectAsState()

    LaunchedEffect(isAuthenticated) {
        if (isAuthenticated) {
            onSuccess()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .testTag("admin_lock_view"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Upper card instructions
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 36.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AdminPanelSettings,
                contentDescription = "Admin lock logo",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Espace Administrateur Sécurisé",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Saisissez votre code PIN à 4 chiffres pour accéder à la base de données des signalements.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        // Code bullets visualizer
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val active = i < pinInput.length
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (isError) MaterialTheme.colorScheme.error
                                else if (active) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                }
            }
            if (isError) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Code PIN Incorrect. Veuillez réessayer.",
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            
            Text(
                "Code par défaut : 1234",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        // Numeric keypad for password entry
        Column(
            modifier = Modifier.width(280.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("Annuler", "0", "Delete")
            )

            rows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    row.forEach { char ->
                        if (char == "Annuler") {
                            TextButton(
                                onClick = {
                                    viewModel.clearAdminPin()
                                    onCancel()
                                },
                                modifier = Modifier.size(width = 80.dp, height = 56.dp)
                            ) {
                                Text("Retour", color = MaterialTheme.colorScheme.primary)
                            }
                        } else if (char == "Delete") {
                            IconButton(
                                onClick = { viewModel.deleteAdminPinDigit() },
                                modifier = Modifier
                                    .size(width = 80.dp, height = 56.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(20.dp))
                            ) {
                                Icon(Icons.Default.Backspace, contentDescription = "Delete digit")
                            }
                        } else {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(width = 80.dp, height = 56.dp)
                                    .background(MaterialTheme.colorScheme.surfaceColorAtElevation(8.dp), RoundedCornerShape(20.dp))
                                    .clickable { viewModel.enterAdminDigit(char) }
                                    .testTag("numpad_$char")
                            ) {
                                Text(
                                    text = char,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------
// ADMIN DASHBOARD VIEW (Gestion des alertes & export)
// ----------------------------------------
@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun AdminDashboardView(viewModel: ReportViewModel) {
    val context = LocalContext.current
    val reports by viewModel.reports.collectAsState()
    val selectedReport by viewModel.selectedReport.collectAsState()
    val playingAudioUri by viewModel.playingAudioUri.collectAsState()

    // Filters and Search Bar State
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("Toutes") }
    var selectedSeverityFilter by remember { mutableStateOf("Toutes") }

    val filteredReports = reports.filter { rep ->
        val matchesSearch = rep.title.contains(searchQuery, ignoreCase = true) ||
                             rep.description.contains(searchQuery, ignoreCase = true) ||
                             (rep.locationAddress ?: "").contains(searchQuery, ignoreCase = true)
        val matchesCat = selectedCategoryFilter == "Toutes" || rep.category == selectedCategoryFilter
        val matchesSev = selectedSeverityFilter == "Toutes" || rep.severity == selectedSeverityFilter
        matchesSearch && matchesCat && matchesSev
    }

    if (selectedReport == null) {
        // LIST OF REPORTS AND SUMMARY counters
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .testTag("admin_dashboard_view"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Dashboard Header with Export action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Tableau de bord Administrateur",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        "${filteredReports.size} signalements filtrés sur ${reports.size} au total",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                
                Button(
                    onClick = { viewModel.triggerExcelExport(context) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E7145), // Classic Excel green
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("export_excel_button")
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Excel (CSV)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Quick status counters row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val total = reports.size
                val pending = reports.count { it.status == "Nouveau" }
                val critical = reports.count { it.severity == "Critique" }
                
                DashboardCounterCard(
                    title = "Total",
                    count = total,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                DashboardCounterCard(
                    title = "Nouveaux",
                    count = pending,
                    color = Color.DarkGray,
                    modifier = Modifier.weight(1f)
                )
                DashboardCounterCard(
                    title = "Critiques",
                    count = critical,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.weight(1f)
                )
            }

            // Search and Filters layout
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher par mot-clé...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Category selector chip
                    var catExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { catExpanded = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text("Cat : $selectedCategoryFilter", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        DropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                            val list = listOf("Toutes", "Sécurité", "Environnement", "Corruption", "Santé publique", "Autre")
                            list.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item) },
                                    onClick = {
                                        selectedCategoryFilter = item
                                        catExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Severity selector chip
                    var sevExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { sevExpanded = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text("Gravité : $selectedSeverityFilter", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        DropdownMenu(expanded = sevExpanded, onDismissRequest = { sevExpanded = false }) {
                            val list = listOf("Toutes", "Faible", "Moyen", "Élevé", "Critique")
                            list.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item) },
                                    onClick = {
                                        selectedSeverityFilter = item
                                        sevExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Reports lazy column list
            if (filteredReports.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Inbox, contentDescription = null, Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Aucun signalement ne correspond à vos filtres.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredReports, key = { it.id }) { report ->
                        ReportRowCard(
                            report = report,
                            onClick = { viewModel.selectReport(report) }
                        )
                    }
                }
            }
        }
    } else {
        // DETAILED ACTIVE REPORT PANEL
        val report = selectedReport!!
        var adminNotesInput by remember(report.id) { mutableStateOf(report.adminNotes) }
        var selectedStatus by remember(report.id) { mutableStateOf(report.status) }
        var showStatusDropdown by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("admin_detail_panel")
        ) {
            // Panel Header and Return Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.selectReport(null) }) {
                    Icon(Icons.AutoMirrored.Default.ArrowBack, contentDescription = "Retour liste")
                }
                Text("Détail du Signalement #${report.id}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                
                IconButton(
                    onClick = {
                        viewModel.deleteReport(report)
                        Toast.makeText(context, "Signalement archivé et définitivement effacé.", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = "Effacer définitivement", tint = MaterialTheme.colorScheme.error)
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Main Info Card
                item {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Catégorie : ${report.category}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp
                            )
                            
                            // Severity Label
                            SeverityIndicatorBadge(report.severity)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(report.title, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        Text(
                            "Reçu le : " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(report.timestamp)),
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                // Description Box
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Description de l'alerte :", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = report.description,
                                modifier = Modifier.padding(12.dp),
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Media Attachment Block
                item {
                    if (report.mediaUri != null) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Pièce jointe média :", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            
                            if (report.mediaType == "image") {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                ) {
                                    AsyncImage(
                                        model = report.mediaUri,
                                        contentDescription = "Image attachée par l'alerte",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            } else {
                                // Mock/Video attachment preview representation
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(120.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.Black)
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.Videocam, "Video Attachment", tint = Color.White, modifier = Modifier.size(36.dp))
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("Vidéo de signalement", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            TextButton(
                                                onClick = {
                                                    try {
                                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                                            setDataAndType(Uri.parse(report.mediaUri), "video/*")
                                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                        }
                                                        context.startActivity(intent)
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "Pas de lecteur vidéo compatible. URI: ${report.mediaUri}", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            ) {
                                                Text("Ouvrir la vidéo", color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Voice Recording Playback Block
                item {
                    if (report.audioUri != null) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Témoignage vocal de l'alerte :", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Card(
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    IconButton(
                                        onClick = { viewModel.playRecordedAudio(report.audioUri) },
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                                            .testTag("audio_play_admin")
                                    ) {
                                        Icon(
                                            imageVector = if (playingAudioUri == report.audioUri) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = "Écouter le témoignage",
                                            tint = Color.White
                                        )
                                    }
                                    Column {
                                        Text("Enregistrement vocal", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            if (playingAudioUri == report.audioUri) "Lecture..." else "Audio - ${report.audioDurationSec} sec",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Geolocation location address block
                item {
                    if (report.latitude != null && report.longitude != null) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Détails Géographiques :", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(report.locationAddress ?: "Localisé", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Coordonnées exactes : ${report.latitude}, ${report.longitude}", fontSize = 11.sp, color = Color.Gray)
                                    
                                    Spacer(modifier = Modifier.height(8.dp))
                                    
                                    // Open default Maps intent
                                    Button(
                                        onClick = {
                                            try {
                                                val uri = Uri.parse("geo:${report.latitude},${report.longitude}?q=${report.latitude},${report.longitude}(Alerte+Citoyenne)")
                                                val intent = Intent(Intent.ACTION_VIEW, uri)
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Impossible d'ouvrir Google Maps.", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.align(Alignment.End),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ouvrir la Carte", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Admin comments and Status update
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Gestion Administrative", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        
                        // Status select field dropdown row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Statut du dossier :", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            
                            Box {
                                Button(
                                    onClick = { showStatusDropdown = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = getStatusColor(selectedStatus)
                                    )
                                ) {
                                    Text(selectedStatus, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                                DropdownMenu(expanded = showStatusDropdown, onDismissRequest = { showStatusDropdown = false }) {
                                    listOf("Nouveau", "En cours", "Traité", "Rejeté").forEach { stat ->
                                        DropdownMenuItem(
                                            text = { Text(stat) },
                                            onClick = {
                                                selectedStatus = stat
                                                showStatusDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = adminNotesInput,
                            onValueChange = { adminNotesInput = it },
                            label = { Text("Notes d'instruction administrative") },
                            placeholder = { Text("Écrivez vos notes d'instruction ou de suivi interne ici...") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 4
                        )

                        Button(
                            onClick = {
                                viewModel.updateReportStatus(report, selectedStatus, adminNotesInput)
                                Toast.makeText(context, "Mise à jour enregistrée avec succès.", Toast.LENGTH_SHORT).show()
                                viewModel.selectReport(null) // Return to list view after save
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_admin_notes_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Enregistrer les modifications", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------
// SUB-COMPONENTS
// ----------------------------------------

@Composable
fun DashboardCounterCard(
    title: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
            Text(count.toString(), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
fun ReportRowCard(
    report: Report,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("report_row_card_${report.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SeverityIndicatorBadge(report.severity)
                    Text(
                        report.category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        if (report.isAnonymous) "🔒 Anonyme" else "👤 Public",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    report.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    report.description,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(2.dp))
                
                // Indicators icons (Camera, Location, Audio note)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    if (report.mediaUri != null) {
                        Icon(
                            if (report.mediaType == "image") Icons.Default.Image else Icons.Default.Videocam,
                            contentDescription = "Attachment present",
                            Modifier.size(12.dp),
                            tint = Color.Gray
                        )
                    }
                    if (report.audioUri != null) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice testimony present", Modifier.size(12.dp), tint = Color.Gray)
                    }
                    if (report.latitude != null) {
                        Icon(Icons.Default.LocationOn, contentDescription = "Coordinates localized", Modifier.size(12.dp), tint = Color.Gray)
                        Text(report.locationAddress ?: "", fontSize = 9.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                // Status tag
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = getStatusColor(report.status).copy(alpha = 0.15f),
                        contentColor = getStatusColor(report.status)
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = report.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(report.timestamp)),
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun SeverityIndicatorBadge(severity: String) {
    val (color, text) = when (severity) {
        "Critique" -> Color(0xFFC62828) to "CRITIQUE"
        "Élevé" -> Color(0xFFEF6C00) to "ÉLEVÉ"
        "Moyen" -> Color(0xFF1565C0) to "MOYEN"
        else -> Color(0xFF2E7D32) to "FAIBLE"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 9.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
        )
    }
}

fun getStatusColor(status: String): Color {
    return when (status) {
        "Nouveau" -> Color(0xFF5D4037)
        "En cours" -> Color(0xFFF57C00)
        "Traité" -> Color(0xFF388E3C)
        "Rejeté" -> Color(0xFFD32F2F)
        else -> Color.DarkGray
    }
}
