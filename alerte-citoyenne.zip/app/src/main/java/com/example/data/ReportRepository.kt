package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportRepository(private val reportDao: ReportDao) {
    val allReports: Flow<List<Report>> = reportDao.getAllReports()

    suspend fun getReportById(id: Int): Report? = reportDao.getReportById(id)

    suspend fun insert(report: Report): Long = reportDao.insertReport(report)

    suspend fun update(report: Report) = reportDao.updateReport(report)

    suspend fun delete(report: Report) = reportDao.deleteReport(report)

    suspend fun deleteById(id: Int) = reportDao.deleteReportById(id)

    /**
     * Exports the list of reports into a standard Excel-compatible CSV file.
     * Uses sep=; on first line to ensure direct Excel compatibility in any locale.
     */
    fun exportToExcelCsv(context: Context, reports: List<Report>): Uri? {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        
        val csvBuilder = StringBuilder()
        csvBuilder.append("sep=;\n") // Force Excel to use semicolon separator
        
        // CSV Headers in French
        csvBuilder.append("ID;Titre;Categorie;Severite;Description;Date;Latitude;Longitude;Adresse;Type_Media;Lien_Media;Lien_Audio;Statut;Notes_Admin;Anonyme\n")
        
        for (report in reports) {
            val dateStr = dateFormat.format(Date(report.timestamp))
            val titleEscaped = escapeCsvCell(report.title)
            val descEscaped = escapeCsvCell(report.description)
            val categoryEscaped = escapeCsvCell(report.category)
            val severityEscaped = escapeCsvCell(report.severity)
            val addressEscaped = escapeCsvCell(report.locationAddress ?: "")
            val mediaTypeEscaped = escapeCsvCell(report.mediaType ?: "Aucun")
            val mediaUriEscaped = escapeCsvCell(report.mediaUri ?: "")
            val audioUriEscaped = escapeCsvCell(report.audioUri ?: "")
            val statusEscaped = escapeCsvCell(report.status)
            val adminNotesEscaped = escapeCsvCell(report.adminNotes)
            val isAnonymousStr = if (report.isAnonymous) "Oui" else "Non"
            
            csvBuilder.append("${report.id};")
                .append("$titleEscaped;")
                .append("$categoryEscaped;")
                .append("$severityEscaped;")
                .append("$descEscaped;")
                .append("$dateStr;")
                .append("${report.latitude ?: ""};")
                .append("${report.longitude ?: ""};")
                .append("$addressEscaped;")
                .append("$mediaTypeEscaped;")
                .append("$mediaUriEscaped;")
                .append("$audioUriEscaped;")
                .append("$statusEscaped;")
                .append("$adminNotesEscaped;")
                .append("$isAnonymousStr\n")
        }

        try {
            // Write file to internal cache directory to easily share via FileProvider
            val fileName = "Signalements_AlerteCitoyenne_${System.currentTimeMillis()}.csv"
            val cacheDir = File(context.cacheDir, "exports")
            if (!cacheDir.exists()) {
                cacheDir.mkdirs()
            }
            val file = File(cacheDir, fileName)
            
            FileOutputStream(file).use { outputStream ->
                // Write standard UTF-8 BOM to satisfy Excel accentuation
                outputStream.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                outputStream.write(csvBuilder.toString().toByteArray(Charsets.UTF_8))
            }
            
            // Get Uri from FileProvider
            return FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun escapeCsvCell(cell: String): String {
        var clean = cell.replace("\n", " ").replace("\r", " ")
        if (clean.contains(";") || clean.contains("\"") || clean.contains(",")) {
            clean = clean.replace("\"", "\"\"")
            clean = "\"$clean\""
        }
        return clean
    }
}
