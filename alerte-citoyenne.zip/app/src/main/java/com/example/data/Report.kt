package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reports")
data class Report(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val category: String, // e.g., "Sécurité", "Environnement", "Corruption", "Santé publique", "Autre"
    val severity: String,  // "Faible", "Moyen", "Élevé", "Critique"
    val timestamp: Long = System.currentTimeMillis(),
    
    // Geolocation info
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationAddress: String? = null,
    
    // Attachments
    val mediaUri: String? = null, // Path or Uri to photo/video
    val mediaType: String? = null, // "image", "video", or null
    val audioUri: String? = null, // Path to voice recording
    val audioDurationSec: Int = 0,
    
    // Administration fields
    val status: String = "Nouveau", // "Nouveau", "En cours", "Traité", "Rejeté"
    val adminNotes: String = "",
    val isAnonymous: Boolean = true
)
